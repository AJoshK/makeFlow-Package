requireNamespace("dplyr")
requireNamespace("magrittr")
utils::suppressForeignCheck(names = "n")
GateSummaries <- function(data, classFields){ 
  Gates <- list(); n = NULL
  for(field in 1:(length(classFields))){
    Gates[[field]] <- dplyr::select_(.data=data,classFields[field])
    Gates[[field]] <- dplyr::group_by_(.data = Gates[[field]],classFields[field]) 
    Gates[[field]] <- dplyr::summarise(.data = Gates[[field]],n=dplyr::n())
    Gates[[field]] <- dplyr::mutate(.data = Gates[[field]],freq=n/sum(n))
    names(Gates)[[field]] <- paste0("Gate_Summary_",field)
  }
  return(Gates)
}