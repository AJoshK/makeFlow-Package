requireNamespace("dplyr")
requireNamespace("magrittr")
utils::suppressForeignCheck(names = "n")
FlowSummaries <- function(data,classFields){
  Flows <- list(); n=NULL
  for(field in 1:(length(classFields)-1)){
    Flows[[field]] <- dplyr::select_(.data = data,classFields[field],classFields[field+1])
    Flows[[field]] <- dplyr::group_by_(.data=Flows[[field]],classFields[field],classFields[field+1])
    Flows[[field]] <- dplyr::summarise(.data = Flows[[field]],n=dplyr::n())
    Flows[[field]] <- dplyr::mutate(.data = Flows[[field]],freq=n/sum(n))
    
    
    names(Flows)[[field]] <- paste0("Flow_Summary_",field)
  }
  return(Flows)
}