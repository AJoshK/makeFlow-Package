colorCount <-
function(data, classFields){
  FieldCats <- c()
  unique_cats <- c()
  for(i in 1:length(gateFields)){
    temp <- data %>% select_(gateFields[i]) %>% group_by_(gateFields[i]) %>% summarise()
    FieldCats <- c(FieldCats,nrow(temp))
    unique_cats <- c(unique_cats,temp[,1])
  }
  
  unique_cats <- unique(as.character(unlist(unique_cats)))
  return(length(unique_cats))
}
