GateSummaries <-
function(data, classFields){ 
  
  for(field in 1:(length(classFields))){
    assign(paste0("Gate_Summary_",field),value = data %>% select_(classFields[field]) %>% group_by_(classFields[field]) %>% summarise(n=n()) %>% mutate(freq=n/sum(n)),envir = .GlobalEnv)
  }
}
