FlowSummaries <-
function(data,classFields){
  for(field in 1:(length(classFields)-1)){
    assign(paste0("Flow_Summary_",field), value=data %>% select_(classFields[field],classFields[field+1]) %>% group_by_(classFields[field],classFields[field+1]) %>% summarise(n=n()) %>% mutate(freq=n/sum(n)), envir = .GlobalEnv)
  }
}
